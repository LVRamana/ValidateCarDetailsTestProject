package TestProject.ValidationTest.Support;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

//import org.hamcrest.Matcher;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CarCheckSteps {
	
	WebDriver driver = new ChromeDriver();
	List<String> carVehicles=new ArrayList<String>();
	List<String[]> vehicleDetailsInTextFile = new ArrayList<String[]>();
	CarCheckPage carCheckPage = new CarCheckPage(driver);
	Hashtable<String, String> vehicleDetailsInTheSite = new Hashtable<String, String>();
	
	
	
	@Given("^I want to read and extract the vehicle registration number from the text file$")
	public void i_want_to_read_and_extract_the_vehicle_registration_number_from_the_text_file() throws Throwable {
	    ReadAndExtractDataFromInputFile();
	}
	
	@When("^I enter the registration number in the free car check website$")
	public void i_enter_the_registration_number_in_the_free_car_check_website() throws Throwable {
		driver.navigate().to("https://cartaxcheck.co.uk/");
		carCheckPage.waitForTheLandingPageToLoad();
		System.out.println(carVehicles);
		for(String carVehicle: carVehicles){
			System.out.println(carVehicle);
			vehicleDetailsInTheSite = carCheckPage.getTheVehicleDetailsFromTheSite(carVehicle);
			System.out.println(vehicleDetailsInTheSite);
		}
		
		
	}
	
	@When("^I click on check vehicle link$")
	public void i_click_on_check_vehicle_link() throws Throwable {
         
	}
	

    @When("^I compare the details in the website with the details in output text file$")
     public void i_compare_the_details_in_the_website_with_the_details_in_output_text_file() throws Throwable {
    	ReadAndExtractDataFromOuputFile();
     }
    
    @Then("^I make sure the details in the text file are correct$")
    public void i_make_sure_the_details_in_the_text_file_are_correct() throws Throwable {
    	assert(vehicleDetailsInTheSite.values().equals(vehicleDetailsInTextFile));

    }
	
	public void ReadAndExtractDataFromInputFile()
	{
 
		List<String> words = new ArrayList<String>();
		try{
		
			File file = new File("car_input.txt");
            Scanner reader = new Scanner(file);
            while(reader.hasNextLine())
			{
		    String text = reader.nextLine();
            BreakIterator breakIterator = BreakIterator.getWordInstance();
		    breakIterator.setText(text);
		    int lastIndex = breakIterator.first();
		    while (BreakIterator.DONE != lastIndex) {
		        int firstIndex = lastIndex;
		        lastIndex = breakIterator.next();
		        if (lastIndex != BreakIterator.DONE && Character.isLetterOrDigit(text.charAt(firstIndex))) {
		            words.add(text.substring(firstIndex, lastIndex));
		        }
            }
         }
         ExtractText(words);
         reader.close();
		
		 } catch(FileNotFoundException e)
		   {
			
		    }
     }

	  public void ExtractText(List<String> words) {
		
		Pattern p1 = Pattern.compile("^[A-Z0-9]*$");
		Pattern p2 = Pattern.compile("^[A-Z]+$");
		outer:
		for(int i=0; i<words.size(); i++){
			for (int j = i+1; j < words.size(); j++) {
				Matcher matcher1 = p1.matcher(words.get(i));
				Matcher matcher2 = p2.matcher(words.get(i));
				Matcher matcher3 = p1.matcher(words.get(j));
				Matcher matcher4 = p2.matcher(words.get(j));
				if(words.get(i).length()==7){
				   String word = words.get(i);
				   if(Character.isLetter(word.charAt(0)) && Character.isLetter(word.charAt(1)) && Character.isDigit(word.charAt(2)) && Character.isDigit(word.charAt(3)) 
		            	&& Character.isLetter(word.charAt(4)) && Character.isLetter(word.charAt(5)) && Character.isLetter(word.charAt(6)))
					   carVehicles.add(words.get(i));
				 }
               	if(matcher1.matches() || matcher2.matches()){
					if(matcher3.matches() || matcher4.matches()){
							String regNumber = words.get(i)+words.get(j);
							carVehicles.add(regNumber);
							
					}
					else
						continue outer;		
				}
                else
				   	 continue outer;
                }                   
			}
		System.out.println(carVehicles);
      }
	  
	  public void ReadAndExtractDataFromOuputFile()
		{
	 
			List<String[]> vehicleDetailsInTextFile = new ArrayList<String[]>();
			try(BufferedReader in = new BufferedReader(new FileReader("car_output.txt"))) {
			String text;
			while ((text = in.readLine()) != null) {
				   String[] details=text.split(",");
			        System.out.println(text);
			        vehicleDetailsInTextFile.add(details);
			    }
			}
		
			catch(IOException e) {
			    System.out.println("File Read Error");
			
			}
	     }

}


        	




