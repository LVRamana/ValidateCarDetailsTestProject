package TestProject.ValidationTest.Support;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class BaseClass {
	
	protected WebDriver driver;
	
	public BaseClass(WebDriver driver){
		this.driver = driver;
	}
	
	public WebDriver getDriver(){
		return driver;
	}	

	public void waitForElementToBeVisisble(By by){
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement element = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(by));
	}
		
	public void waitForAnElement(){
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		
	}
	public void scrollToElement(WebElement element){
	
	      Actions actions = new Actions(driver);
	      actions.moveToElement(element);
	      actions.perform();
	}

	
	

}
