package TestProject.ValidationTest.Support;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserFactory {
	
	public static WebDriver driver;
	
	public BrowserFactory(){
		
	}
	
	public static WebDriver getDriver(){
		if(driver==null){
			System.setProperty("webdriver.chrome.driver", "chromedriver");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			
		}
		return driver;
	}

}
