package TestProject.ValidationTest.Support;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CarCheckPage extends BaseClass {

        public CarCheckPage(WebDriver driver) {
    		super(driver);
    		PageFactory.initElements(driver, this);
    	}
        @FindBy(how=How.XPATH, using="//h1[text()='Free Car Check']")
		public WebElement freeCarCheckHeader;
      
        
        @FindBy(how=How.XPATH, using="//input[@id='vrm-input']")
		public WebElement enterRegistration;
        
        @FindBy(how=How.XPATH, using="//button[text()='Free Car Check']")
        public WebElement freecarCheck;
        
        @FindBy(how=How.XPATH, using="//h4[text()='Vehicle Identity']")
        public WebElement vehicleIdentity;
        
        @FindBy(how=How.XPATH, using="//dt[text()='Registration']")
        public WebElement registration;
        
        @FindBy(how=How.XPATH, using="//dt[text()='Registration']/../dd")
        public WebElement registrationNumber;
        
        @FindBy(how=How.XPATH, using="//dt[text()='Make']")
        public WebElement make;
        
        @FindBy(how=How.XPATH, using="//dt[text()='Make']/../dd")
        public WebElement vehicleMake;
        
        @FindBy(how=How.XPATH, using="//dt[text()='Model']")
        public WebElement model;
        
        @FindBy(how=How.XPATH, using="//dt[text()='Model']/../dd")
        public WebElement modelNumber;
        
        @FindBy(how=How.XPATH, using="//dt[text()='Colour']")
        public WebElement colour;
        
        @FindBy(how=How.XPATH, using="//dt[text()='Colour']/../dd")
        public WebElement vehicleColour;
        
        @FindBy(how=How.XPATH, using="//dt[text()='Year']")
        public WebElement year;
        
        @FindBy(how=How.XPATH, using="//dt[text()='Year']/../dd")
        public WebElement vehicleYear;
      
        
        public Hashtable<String, String> getTheVehicleDetailsFromTheSite(String vehicleName){
        	enterRegistrationNumber(vehicleName);
        	clickOnButton();
        	scrollToElement(vehicleIdentity);
        	Hashtable<String, String> vehicleDetailsFromSite = new Hashtable<String, String>();
        	vehicleDetailsFromSite.put(registration.getText(), registrationNumber.getText());
        	vehicleDetailsFromSite.put(make.getText(), vehicleMake.getText());
        	vehicleDetailsFromSite.put(model.getText(), modelNumber.getText());
        	vehicleDetailsFromSite.put(colour.getText(), vehicleColour.getText());
        	vehicleDetailsFromSite.put(year.getText(), vehicleYear.getText());
        	driver.navigate().back();
        	return vehicleDetailsFromSite;
        	
        }
      
        
        public void enterRegistrationNumber(String number){
        	waitForAnElement();
        	enterRegistration.clear();
        	enterRegistration.sendKeys(number);
        	waitForElementToBeVisisble(By.xpath("//button[text()='Free Car Check']"));
        }
        
        public void clickOnButton(){
        	freecarCheck.click();
        	waitForElementToBeVisisble(By.xpath("//h4[text()='Vehicle Identity']"));
        }
        
        public void waitForTheLandingPageToLoad()
        {
        	waitForElementToBeVisisble(By.xpath("//h1[text()='Free Car Check']"));
        	waitForElementToBeVisisble(By.xpath("//input[@id='vrm-input']"));
        	waitForElementToBeVisisble(By.xpath("//button[text()='Free Car Check']"));    	
        }
        
        
}
